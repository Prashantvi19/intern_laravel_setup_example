<h1>Show Details </h1>
Name: {{$data['name']}} <br>
Email: {{$data['email']}} <br>
Contact: {{$data['contact']}} <br>
Message: {{$data['message']}} <br>


<a href="{{url('contact')}}"> <-- Back</a>