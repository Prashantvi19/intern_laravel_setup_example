composer create-project laravel/laravel example-app

composer require laravel/ui

php artisan ui vue --auth

npm install

npm run dev


example.com/login

example.com/register