<?php $__env->startSection('content'); ?>

<h1>Welcome</h1>

<pre>
	<h2>Welcome</h2>
Srb It Solution is a World-Class Software
Development and IT Consulting Company based in INDORE (MP),  delivering business solutions globally using full stack Microsoft and open-source technologies.

We provide a complete IT solution start from
Web & App development, Standard software & solutions.
We are expert in Web Development, 
Mobile App Development,
UI/UX Design & Front-End Development. 
We have more than 8 years of experience in software development field.
</pre>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\training23\resources\views/welcome.blade.php ENDPATH**/ ?>