<a href="/">Home</a>
	<a href="/about">About</a>
	<a href="/contact">Contact</a><?php /**PATH C:\xampp\htdocs\laravel\training23\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>