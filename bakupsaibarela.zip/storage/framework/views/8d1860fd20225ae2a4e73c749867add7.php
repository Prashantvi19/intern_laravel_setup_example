<h1>Edit Details </h1>

<form action="<?php echo e(url('contactUpdate')); ?>" method="POST">
	<?php echo csrf_field(); ?>
<input type="hidden" name="id" value="<?php echo e($data['id']); ?>">	
Name: <input type="text" name="name" value="<?php echo e($data['name']); ?>"> <br>
Email: <input type="text" name="email" value="<?php echo e($data['email']); ?>"><br>
Contact: <input type="text" name="contact" value="<?php echo e($data['contact']); ?>"><br>
Message: <input type="text" name="message" value="<?php echo e($data['message']); ?>"> <br>

<input type="submit" name="submit" value="Update">

</form>

<a href="<?php echo e(url('contact')); ?>"> <-- Back</a><?php /**PATH C:\xampp\htdocs\laravel\training23\resources\views/contact/edit.blade.php ENDPATH**/ ?>