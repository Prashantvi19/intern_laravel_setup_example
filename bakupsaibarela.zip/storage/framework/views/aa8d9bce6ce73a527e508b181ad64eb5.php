<h1>User List</h1>
<?php
	$myAry =[ 
				[
					'name'=>'Ram',
					'email' => 'Ram@gmail.com',
					'contact' => '7878787878'
				],
				[
					'name'=>'Mohan',
					'email' => 'Ram@gmail.com',
					'contact' => '555555555'
				],
				[
					'name'=>'Shyam',
					'email' => 'Shyam@gmail.com',
					'contact' => '88888888'
				]
			];
?>

<table border="1">
	<thead>
		<th>Name</th>
		<th>Email</th>
		<th>Contact</th>
	</thead>
	<tbody>
		<?php $__currentLoopData = $myAry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($val['name']); ?></td>
			<td><?php echo e($val['email']); ?></td>
			<td><?php echo e($val['contact']); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php /**PATH C:\xampp\htdocs\laravel\training23\resources\views/users/index.blade.php ENDPATH**/ ?>