

<?php $__env->startSection('content'); ?>

<h1>Contact List</h1>

<table border="1">
	<thead>
		<th>S/no</th>
		<th>Name</th>
		<th>Email</th>
		<th>Contact</th>
		<th>View</th>
		<th>Edit</th>
		<th>Delete</th>
	</thead>
	<tbody>
		<?php $i = 1; ?>
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($i++); ?></td>
			<td><?php echo e($val['name']); ?></td>
			<td><?php echo e($val['email']); ?></td>
			<td><?php echo e($val['contact']); ?></td>
			<td><a href="<?php echo e(url('contact/'.$val['id'])); ?>">View</a></td>
			<td><a href="<?php echo e(url('contactEdit/'.$val['id'])); ?>">Edit</a></td>
			<td><a href="<?php echo e(url('contactDelete/'.$val['id'])); ?>">Delete</a></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>

<?php echo e($data->links()); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\training23\resources\views/contact/index.blade.php ENDPATH**/ ?>