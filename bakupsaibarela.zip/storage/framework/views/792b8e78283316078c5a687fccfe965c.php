<h1>Show Details </h1>
Name: <?php echo e($data['name']); ?> <br>
Email: <?php echo e($data['email']); ?> <br>
Contact: <?php echo e($data['contact']); ?> <br>
Message: <?php echo e($data['message']); ?> <br>


<a href="<?php echo e(url('contact')); ?>"> <-- Back</a><?php /**PATH C:\xampp\htdocs\laravel\training23\resources\views/contact/show.blade.php ENDPATH**/ ?>