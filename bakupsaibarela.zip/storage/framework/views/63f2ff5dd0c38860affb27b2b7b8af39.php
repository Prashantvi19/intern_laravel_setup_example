<h1>Features</h1>

<?php
	$name = 'ram';
	$lastName = 'mohan';
?>

Your name is : <?php echo e(ucFirst($name)); ?> <?php echo e($lastName); ?>


<h2>For Loop</h2>
<?php for($i=4;$i>=0;$i--): ?>
	<p><?php echo e($i); ?></p>
<?php endfor; ?>

<h2>ForEach Loop</h2>
<?php
	$myAry =[ 
				[
					'name'=>'Ram',
					'email' => 'Ram@gmail.com',
					'contact' => '7878787878'
				],
				[
					'name'=>'Mohan',
					'email' => 'Ram@gmail.com',
					'contact' => '555555555'
				],
				[
					'name'=>'Shyam',
					'email' => 'Shyam@gmail.com',
					'contact' => '88888888'
				]
			];
?>

<table border="1">
	<thead>
		<th>Name</th>
		<th>Email</th>
		<th>Contact</th>
	</thead>
	<tbody>
		<?php $__currentLoopData = $myAry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($val['name']); ?></td>
			<td><?php echo e($val['email']); ?></td>
			<td><?php echo e($val['contact']); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>


<h2>If </h2>
<?php
	$email ='admin@gmail.com';
?>

<?php if($email == 'admin@gmail.com'): ?>
	You are admin.....
<?php endif; ?>


<h2>If else</h2>

<?php if($email == 'user@gmail.com'): ?>
	You are admin.....
<?php else: ?>
	You are not admin.....
<?php endif; ?>





<?php /**PATH C:\xampp\htdocs\laravel\training23\resources\views/features.blade.php ENDPATH**/ ?>